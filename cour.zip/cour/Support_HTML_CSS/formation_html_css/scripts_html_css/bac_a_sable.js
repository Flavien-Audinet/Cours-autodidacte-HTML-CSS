

function definirCouleur() {
        /* récupération des choix : */
        var choixFondParagraphe = document.getElementById("FondParagraphe");
		var choixCouleurParagraphe = document.getElementById("CouleurParagraphe");
		var choixCouleurImportant = document.getElementById("CouleurImportant");

        /* application des choix à la boite d'illustration : */
        var boiteIllustrative = document.getElementById("boiteIllustrative");
        boiteIllustrative.style.backgroundColor = choixFondParagraphe.value;
        boiteIllustrative.style.color = choixCouleurParagraphe.value;
        
		var important = document.getElementById("important");
        important.style.color = choixCouleurImportant.value;
        
		/*  affichage des choix :  */ 
        var lecode = document.getElementById("lecode");

        var chaine ='';
        chaine += 'p {';
		chaine += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += '/* Mise en forme des paragraphes */<br>';
		chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'background-color: ' + choixFondParagraphe.value + '; <br>';
		chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'color: ' + choixCouleurParagraphe.value + '; <br>';
		chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine +=  '} <br><br>';
        chaine += 'strong {';
		chaine += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += '/* Mise en forme des mots importants */<br>';
		chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'color: ' + choixCouleurImportant.value + '; <br>';
		chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine +=  '}';
        lecode.innerHTML = chaine;
		}


function definirBordure() {
        /* récupération des choix : */
        var choixEpaisseur = document.getElementById("choixEpaisseur");
        var choixStyle = document.getElementById("choixStyle");
        var choixCouleur = document.getElementById("choixCouleur");


        /* application des choix à la boite d'illustration : */
        var boiteIllustrative = document.getElementById("boiteIllustrative");
        boiteIllustrative.style.borderWidth = choixEpaisseur.value+'px';
        boiteIllustrative.style.borderColor = choixCouleur.value;
        boiteIllustrative.style.borderStyle = choixStyle.value;

        /*  affichage des choix :  */ 
        var lecode = document.getElementById("lecode_1");

        var chaine ='';
        chaine += 'p {';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += '/* Mise en forme des paragraphes */<br>';
		chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'border-width : ' + choixEpaisseur.value + 'px; <br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'border-style : ' +  choixStyle.value + '; <br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'border-color : ' +  choixCouleur.value + '; <br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += '}';
        lecode.innerHTML = chaine;

        /*  affichage du raccourci :  */ 
        var lecode2 = document.getElementById("lecode2_1");

        var chaine ='';
        chaine += 'p { <br> ';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp; ';
        chaine += 'border : ' + choixEpaisseur.value + 'px ' + choixStyle.value + ' ' + choixCouleur.value + '; <br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp; ';
        chaine += '}';
        lecode2.innerHTML = chaine;
		}


function definirBordure2() {
        /* récupération des choix pour le haut : */
        var choixEpaisseurHaut = document.getElementById("choixEpaisseurHaut");
        var choixStyleHaut = document.getElementById("choixStyleHaut");
        var choixCouleurHaut = document.getElementById("choixCouleurHaut");

		/* récupération des choix pour la droite : */
        var choixEpaisseurDroit = document.getElementById("choixEpaisseurDroit");
        var choixStyleHautDroit = document.getElementById("choixStyleDroit");
        var choixCouleurHautDroit = document.getElementById("choixCouleurDroit");

		/* récupération des choix pour le bas : */
        var choixEpaisseurBas = document.getElementById("choixEpaisseurBas");
        var choixStyleBas = document.getElementById("choixStyleBas");
        var choixCouleurBas = document.getElementById("choixCouleurBas");

		/* récupération des choix pour la gauche : */
        var choixEpaisseurGauche = document.getElementById("choixEpaisseurGauche");
        var choixStyleGauche = document.getElementById("choixStyleGauche");
        var choixCouleurGauche = document.getElementById("choixCouleurGauche");


        /* application des choix à la boite d'illustration : */
        var boiteIllustrative = document.getElementById("boiteIllustrative2");
		
        boiteIllustrative.style.borderTopWidth = choixEpaisseurHaut.value+'px';
        boiteIllustrative.style.borderTopColor = choixCouleurHaut.value;
        boiteIllustrative.style.borderTopStyle = choixStyleHaut.value;
		
        boiteIllustrative.style.borderRightWidth = choixEpaisseurDroit.value+'px';
        boiteIllustrative.style.borderRightColor = choixCouleurDroit.value;
        boiteIllustrative.style.borderRightStyle = choixStyleDroit.value;
		
        boiteIllustrative.style.borderBottomWidth = choixEpaisseurBas.value+'px';
        boiteIllustrative.style.borderBottomColor = choixCouleurBas.value;
        boiteIllustrative.style.borderBottomStyle = choixStyleBas.value;
		
        boiteIllustrative.style.borderLeftWidth = choixEpaisseurGauche.value+'px';
        boiteIllustrative.style.borderLeftColor = choixCouleurGauche.value;
        boiteIllustrative.style.borderLeftStyle = choixStyleGauche.value;

        /*  affichage des choix :  */ 
        var lecode = document.getElementById("lecode_2");

        var chaine ='';
        chaine += 'p {';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += '/* Mise en forme des paragraphes */<br>';
		chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'border-top : ' + choixEpaisseurHaut.value + 'px ' + choixStyleHaut.value + ' ' + choixCouleurHaut.value + '; <br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'border-right : ' + choixEpaisseurDroit.value + 'px ' + choixStyleDroit.value + ' ' + choixCouleurDroit.value + '; <br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'border-bottom : ' + choixEpaisseurBas.value + 'px ' + choixStyleBas.value + ' ' + choixCouleurBas.value + '; <br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'border-left : ' + choixEpaisseurGauche.value + 'px ' + choixStyleGauche.value + ' ' + choixCouleurGauche.value + '; <br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += '}';
        lecode.innerHTML = chaine;
		}


function definirBordure3() {
        /* récupération des choix : */
        var choixEpaisseur = document.getElementById("choixEpaisseurArrondi");
        var choixStyle = document.getElementById("choixStyleArrondi");
        var choixCouleur = document.getElementById("choixCouleurArrondi");
        var BBLR = document.getElementById("choixBBLR");
        var BBRR = document.getElementById("choixBBRR");
        var BTLR = document.getElementById("choixBTLR");
        var BTRR = document.getElementById("choixBTRR");


        /* application des choix à la boite d'illustration : */
        var boiteIllustrative = document.getElementById("boiteIllustrative3");
        boiteIllustrative.style.borderWidth = choixEpaisseur.value+'px';
        boiteIllustrative.style.borderColor = choixCouleur.value;
        boiteIllustrative.style.borderStyle = choixStyle.value;
		boiteIllustrative.style.borderRadius = BTLR.value+'px '+BTRR.value+'px '+BBRR.value+'px '+BBLR.value+'px ';
		
        /*  affichage des choix :  */ 
        var lecode = document.getElementById("lecode_3");

        var chaine ='';
        chaine += 'p {';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += '/* Mise en forme des paragraphes */<br>';
		chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'border : ' + choixEpaisseur.value + 'px ' + choixStyle.value + ' ' + choixCouleur.value + '; <br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'border-radius : ' + BTLR.value+'px '+BTRR.value+'px '+BBRR.value+'px '+BBLR.value+'px;<br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += '}';
        lecode.innerHTML = chaine;
		}


function definirTexte() {
        /* récupération des choix : */
        var choixCouleur = document.getElementById("choixCouleur");
        var choixTaille = document.getElementById("choixTaille");
        var choixPolice = document.getElementById("choixPolice");
        var choixGraisse = document.getElementById("choixGraisse");
        var choixItalique = document.getElementById("choixItalique");
        var choixDecoration = document.getElementById("choixDecoration");
        var choixMajuscules = document.getElementById("choixMajuscules");


        /* application des choix à la boite d'illustration : */
        var boiteIllustrative = document.getElementById("boiteIllustrative");
        boiteIllustrative.style.color = choixCouleur.value;
        boiteIllustrative.style.fontSize = choixTaille.value+'px';
        boiteIllustrative.style.fontFamily = choixPolice.value;
        boiteIllustrative.style.fontWeight = choixGraisse.value;
        boiteIllustrative.style.fontStyle = choixItalique.value;
        boiteIllustrative.style.textDecoration = choixDecoration.value;
        boiteIllustrative.style.fontVariant = choixMajuscules.value;
		
        /*  affichage des choix :  */ 
        var lecode = document.getElementById("lecode");

        var chaine ='';
        chaine += 'p {';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += '/* Mise en forme des paragraphes */<br>';
		chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'color : ' + choixCouleur.value + '; <br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'font-size : ' + choixTaille.value + 'px ;<br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'font-family : ' + choixPolice.value + ';<br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'font-weight : ' + choixGraisse.value + ';<br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'font-style : ' + choixItalique.value + ';<br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'text-decoration : ' + choixDecoration.value + ';<br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'font-variant : ' + choixMajuscules.value + '; <br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += '}';
        lecode.innerHTML = chaine;
		}


function ombrer() {
        /* récupération des choix : */
        var decalageHorizontalTexte = document.getElementById("decalageHorizontalTexte");
        var decalageVerticalTexte = document.getElementById("decalageVerticalTexte");
        var flouTexte = document.getElementById("flouTexte");
        var couleurOmbreTexte = document.getElementById("couleurOmbreTexte");
        var interligne = document.getElementById("interligne");

		var decalageHorizontalBoite = document.getElementById("decalageHorizontalBoite");
        var decalageVerticalBoite = document.getElementById("decalageVerticalBoite");
        var flouBoite = document.getElementById("flouBoite");
        var couleurOmbreBoite = document.getElementById("couleurOmbreBoite");
		

        /* application des choix à la boite d'illustration : */
        var boiteIllustrative = document.getElementById("boiteIllustrative2");
        boiteIllustrative.style.textShadow = decalageHorizontalTexte.value + 'px ' + decalageVerticalTexte.value + 'px ' + flouTexte.value+'px '+couleurOmbreTexte.value;
        boiteIllustrative.style.lineHeight = interligne.value;
		boiteIllustrative.style.boxShadow = decalageHorizontalBoite.value + 'px ' + decalageVerticalBoite.value + 'px ' + flouBoite.value+'px '+couleurOmbreBoite.value;
        
		
        /*  affichage des choix :  */ 
        var lecode = document.getElementById("lecode_2");

        var chaine ='';
        chaine += 'p {';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += '/* Mise en forme des paragraphes */<br>';
		chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'text-shadow: ' +  decalageHorizontalTexte.value + 'px ';
        chaine +=  decalageVerticalTexte.value + 'px ' + flouTexte.value + 'px '+ couleurOmbreTexte.value + '; <br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'line-height: ' +  interligne.value + '; <br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'box-shadow: ' +  decalageHorizontalBoite.value + 'px ';
        chaine +=  decalageVerticalBoite.value + 'px ' + flouBoite.value + 'px '+ couleurOmbreBoite.value + '; <br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += '}';
        lecode.innerHTML = chaine;
		}


function definirDimensions() {
        /* récupération des choix : */
        var choixLargeur = document.getElementById("choixLargeur");
        var choixHauteur = document.getElementById("choixHauteur");
        var choixEpaisseur = document.getElementById("choixEpaisseur");
        var choixStyle = document.getElementById("choixStyle");
        var choixCouleur = document.getElementById("choixCouleur");
        var choixPadding = document.getElementById("choixPadding");
        var choixMargin = document.getElementById("choixMargin");


        /* application des choix à la boite d'illustration : */
        var boiteIllustrative = document.getElementById("boiteIllustrative");
        boiteIllustrative.style.width = choixLargeur.value+'px';
        boiteIllustrative.style.height = choixHauteur.value+'px';
        boiteIllustrative.style.borderWidth = choixEpaisseur.value+'px';
        boiteIllustrative.style.borderStyle = choixStyle.value;
        boiteIllustrative.style.borderColor = choixCouleur.value;
        boiteIllustrative.style.padding = choixPadding.value+'px';
        boiteIllustrative.style.margin = choixMargin.value+'px';
		
        /*  affichage des choix :  */ 
        var lecode = document.getElementById("lecode");

        var chaine ='';
        chaine += 'p {';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += '/* Mise en forme des paragraphes */<br>';
		chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'width : ' + choixLargeur.value + 'px ;<br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'height : ' + choixHauteur.value + 'px ;<br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'border : ' + choixEpaisseur.value + 'px ' + choixStyle.value + ' ' + choixCouleur.value + '; <br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'padding : ' + choixPadding.value + 'px ;<br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'margin : ' + choixMargin.value + 'px ;<br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += '}';
        lecode.innerHTML = chaine;
		}


function definirFlex() {
        /* récupération des choix : */
        var choixDirection = document.getElementById("choixDirection").value;
        var choixWrap = document.getElementById("choixWrap").value;
        var choixAlign1 = document.getElementById("choixAlign1").value;
        var choixAlign2 = document.getElementById("choixAlign2").value;


        /* application des choix à la boite d'illustration : */
        var boiteIllustrative = document.getElementById("boiteIllustrative");
        boiteIllustrative.style.display = 'flex';
        boiteIllustrative.style.flexDirection = choixDirection;
        boiteIllustrative.style.flexWrap = choixWrap;
        boiteIllustrative.style.justifyContent = choixAlign1;
        boiteIllustrative.style.alignItems = choixAlign2;
		
        /*  affichage des choix :  */ 
        var lecode = document.getElementById("lecode");

        var chaine ='';
        chaine += 'p {';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += '/* Mise en forme des paragraphes */<br>';
		chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'display: flex;<br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'flex-direction: ' + choixDirection + ';<br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'flex-wrap: ' + choixWrap + ';<br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'justify-content: ' + choixAlign1 + ';<br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'align-items: ' + choixAlign2 + ';<br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += '}';
        lecode.innerHTML = chaine;
		}


function definirHover() {
        /* récupération des choix : */
        var choixArrierePlan = document.getElementById("choixArrierePlan").value;
		var choixCouleur = document.getElementById("choixCouleur").value;
		var choixEpaisseur = document.getElementById("choixEpaisseur").value;
		var choixStyleBordure = 'solid';
		var choixGraisse = document.getElementById("choixGraisse").value;
		var choixDecoration = document.getElementById("choixDecoration").value;

        /* application des choix à la boite d'illustration : */
        var boiteIllustrative = document.getElementById("boiteIllustrative");
        boiteIllustrative.style.backgroundImage = 'url('+choixArrierePlan+')';
        boiteIllustrative.style.borderColor = choixCouleur;
        boiteIllustrative.style.borderWidth = choixEpaisseur+'px';
        boiteIllustrative.style.borderStyle = choixStyleBordure;
        boiteIllustrative.style.fontWeight = choixGraisse;
        boiteIllustrative.style.textDecoration = choixDecoration;
		}


function definirNormal() {
        var boiteIllustrative = document.getElementById("boiteIllustrative");
        boiteIllustrative.style.backgroundImage = "";
        boiteIllustrative.style.borderColor = 'black';
        boiteIllustrative.style.borderWidth = '0';
        boiteIllustrative.style.borderStyle = 'solid';
        boiteIllustrative.style.fontWeight = 'normal';
        boiteIllustrative.style.textDecoration = 'none';
		}


function affichageHover() {
        /* récupération des choix : */
        var choixArrierePlan = document.getElementById("choixArrierePlan").value;
		var choixCouleur = document.getElementById("choixCouleur").value;
		var choixEpaisseur = document.getElementById("choixEpaisseur").value;
		var choixStyleBordure = 'solid';
		var choixGraisse = document.getElementById("choixGraisse").value;
		var choixDecoration = document.getElementById("choixDecoration").value;

        /*  affichage des choix :  */ 
        var lecode = document.getElementById("lecode");

        var chaine ='';
        chaine += 'p:hover {';
		chaine += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += '/* Mise en forme lors du survol */<br>';
		chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'background-image: url=(' + choixArrierePlan + '); <br>';
		chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'border: ' + choixEpaisseur + 'px ' + choixStyleBordure +' '+ choixCouleur + '; <br>';
        chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'font-weight: ' + choixGraisse + '; <br>';
		chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine += 'text-decoration: ' + choixDecoration + '; <br>';
		chaine += '&nbsp;&nbsp;&nbsp;&nbsp;';
        chaine +=  '}';
        lecode.innerHTML = chaine;
		}

	