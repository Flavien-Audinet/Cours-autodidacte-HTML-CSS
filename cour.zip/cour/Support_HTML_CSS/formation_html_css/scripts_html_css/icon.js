

( function () {

    /* l'icone du module, chemin donn� � partir de la racine du module */
    
    let image = "images_html_css/logo_HTML5_2.png";


    /* rien � modifier en dessous */

    let objet_link  = document.createElement('link');
    
    objet_link.rel  = 'shortcut icon';
    objet_link.type = 'image/x-icon';

    url = document.currentScript.src.slice(0,document.currentScript.src.lastIndexOf("/"))
    url = url.slice(0,url.lastIndexOf("/"))+"/"+image;

    objet_link.href = url;
    
    document.head.appendChild( objet_link);

}) ();
